insert into clientes values
(default,'98116-8642','31159482802','givar1200k@yahoo.com.br','15002728','Givanildo','2017-04-21'),
(default,'98824-0967','40856136859','givahits@gmail.com','15002691','Xtreme','2017-04-21');

insert into atendentes values
(default,'Paulo','PLO002','1234','1','2017-04-21'),
(default,'João','JPPO002','5678','1','2017-04-21');

insert into notas values
(default,8,1,true),
(default,5,1,false);

insert into questionarios value
(default,1,1,1,'1234',true,'2017-04-21','1');