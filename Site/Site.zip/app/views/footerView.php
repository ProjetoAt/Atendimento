	<footer class="footer">
		<a class="footer__link" href="#">MIT License © Projeto Atendimento</a>
	</footer>
</div>

</body>
</html>